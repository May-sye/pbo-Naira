const express = require("express");
const { login, verifyRole } = require("../controllers/authController");

const router = express.Router();

router.post("/login", login);

// Example Protected Routes
router.get("/admin", verifyRole("admin"), (req, res) => {
    res.status(200).json({ message: "Welcome Admin" });
});

router.get("/user", verifyRole("user"), (req, res) => {
    res.status(200).json({ message: "Welcome User" });
});

module.exports = router;
