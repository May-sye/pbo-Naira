const db = require("../models/db");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

// Login User
exports.login = (req, res) => {
    const { username, password } = req.body;

    db.query("SELECT * FROM users WHERE username = ?", [username], async (err, results) => {
        if (err) return res.status(500).json({ message: "Database error" });

        if (results.length === 0) {
            return res.status(401).json({ message: "User not found" });
        }

        const user = results[0];
        const match = await bcrypt.compare(password, user.password);

        if (!match) {
            return res.status(401).json({ message: "Invalid credentials" });
        }

        const token = jwt.sign({ id: user.id, role: user.role }, "secret_key", { expiresIn: "1h" });
        res.status(200).json({ token, role: user.role });
    });
};

// Middleware to Verify Roles
exports.verifyRole = (role) => (req, res, next) => {
    const token = req.headers["authorization"];
    if (!token) return res.status(403).json({ message: "No token provided" });

    jwt.verify(token, "secret_key", (err, decoded) => {
        if (err) return res.status(401).json({ message: "Unauthorized" });

        if (decoded.role !== role) {
            return res.status(403).json({ message: "Access denied" });
        }
        next();
    });
};
