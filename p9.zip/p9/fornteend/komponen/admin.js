import React from "react";

const Admin = () => <h1>Welcome, Admin!</h1>;
const User = () => <h1>Welcome, User!</h1>;

export { Admin, User };
